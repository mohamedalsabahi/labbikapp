import 'package:flutter/material.dart';
import 'home.dart';
import 'package:splashscreen/splashscreen.dart';
import 'package:sellers_app/pages_ar/callcenter.dart';

void main(){
  runApp(new MaterialApp(
    home: new MyApp(),
  ));
}


class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => new _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return new SplashScreen(
      seconds: 5,
      navigateAfterSeconds: new home(),
      title: new Text('مرحبا بك في لبيك ',
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 25.0
        ),

      ),
      image:  Image.asset("images/la.png"),

      backgroundColor: Colors.white,
      styleTextUnderTheLoader: new TextStyle(),
      photoSize: 100.0,
      onClick: (){},
      loaderColor: Colors.red,
    );
  }
}

//class AfterSplash extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return  runApp(new MaterialApp(
//      title: "home",
//      home: new home(),
//    ));
//  };
//}