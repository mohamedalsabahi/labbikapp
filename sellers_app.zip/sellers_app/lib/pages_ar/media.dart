import 'package:flutter/material.dart';
import 'package:sellers_app/main.dart';
import 'package:sellers_app/home.dart';
import 'package:sellers_app/category.dart';
import 'package:carousel_pro/carousel_pro.dart';



class media extends StatefulWidget{
  @override
  call_center createState() => new call_center();

}

class call_center extends State<media>{
  @override
  Widget build(BuildContext context) {

    return   Scaffold(
      backgroundColor: Color(0xffD4AF4B),
      appBar: new AppBar(
        backgroundColor: Color(0xffD4AF4B),
        title: new Text("لبيك ميديا"),
//        shape: RoundedRectangleBorder(
//          borderRadius: BorderRadius.circular(18.0),
//        ),
      ),
      body: new Container(
        margin: EdgeInsets.only(top: 5),
        width:  MediaQuery.of(context).size.width ,

        height: MediaQuery.of(context).size.height,
        child: new Card(

          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13.0)),

          child: SizedBox(

              height: 200.0,
              width: 400.0,
              child: Carousel(

                images: [
//                  NetworkImage('https://cdn-images-1.medium.com/max/2000/1*GqdzzfB_BHorv7V2NV7Jgg.jpeg'),
//                  NetworkImage('https://cdn-images-1.medium.com/max/2000/1*wnIEgP1gNMrK5gZU7QS0-A.jpeg'),
//                  NetworkImage('https://cdn-images-1.medium.com/max/2000/1*wnIEgP1gNMrK5gZU7QS0-A.jpeg'),
                  Image.asset("images/10.png"),
                  Image.asset("images/media2.png"),
//                  Image.asset("images/11.png"),
                  Image.asset("images/12.png"),
//            ExactAssetImage("assets/images/LaunchImage.jpg")
                ],
                autoplay: false,
                dotSize: 4.0,
                dotSpacing: 15.0,
                dotColor: Color(0xffBB903D),
                indicatorBgPadding: 5.0,
                dotBgColor: Color(0xffBB903D).withOpacity(0.5),
                borderRadius: true,
                moveIndicatorFromBottom: 180.0,
                noRadiusForIndicator: true,
                overlayShadow: true,
                overlayShadowColors: Color(0xffBB903D),
                overlayShadowSize: 0.7,
              )
          ),

        ),
      ),
    );
  }

}