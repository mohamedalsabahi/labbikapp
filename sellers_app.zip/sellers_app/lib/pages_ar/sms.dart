
import 'package:flutter/material.dart';
import 'package:sellers_app/main.dart';
import 'package:sellers_app/home.dart';
import 'package:sellers_app/category.dart';
import 'package:carousel_pro/carousel_pro.dart';



class sms extends StatefulWidget{
  @override
  call_center createState() => new call_center();

}

class call_center extends State<sms>{
  @override
  Widget build(BuildContext context) {

    return   Scaffold(
//      backgroundColor: Colors.orangeAccent,
      appBar: new AppBar(
        backgroundColor: Color(0xffD4AF4B),

        title: new Text("الرسائل النصية القصيرة"),
//        shape: RoundedRectangleBorder(
//          borderRadius: BorderRadius.circular(18.0),
//        ),
      ),
      body: new Container(
        margin: EdgeInsets.only(top: 5),
        width:  MediaQuery.of(context).size.width ,

        height: MediaQuery.of(context).size.height,
        child: new Card(

          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13.0)),

          child: SizedBox(

              height: 200.0,
              width: 400.0,
              child: Carousel(
                images: [
//                  NetworkImage('https://ma.thebest-code.com/Apis/Api/images/ma/4.png'),
//                  NetworkImage('https://ma.thebest-code.com/Apis/Api/images/ma/5.png'),
                  Image.asset("images/5.png"),
                  Image.asset("images/6.png"),
//            ExactAssetImage("assets/images/LaunchImage.jpg")
                ],
                autoplay: false,
                dotSize: 4.0,
                dotSpacing: 15.0,
                dotColor: Color(0xffBB903D),
                indicatorBgPadding: 5.0,
                dotBgColor: Color(0xffBB903D).withOpacity(0.5),
                borderRadius: true,
                moveIndicatorFromBottom: 180.0,
                noRadiusForIndicator: true,
                overlayShadow: true,
                overlayShadowColors: Color(0xffBB903D),
                overlayShadowSize: 0.7,
              )
          ),

        ),
      ),
    );
  }

}