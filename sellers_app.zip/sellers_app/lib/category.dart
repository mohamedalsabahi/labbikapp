import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'main.dart';
import 'home.dart';
import 'package:sellers_app/pages_ar/callcenter.dart';
import 'package:sellers_app/pages_ar/callcenter.dart';
import 'package:sellers_app/pages_ar/sms.dart';
import 'package:sellers_app/pages_ar/tellmarkting.dart';
import 'package:sellers_app/pages_ar/media.dart';



class category extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    final data = MediaQuery.of(context);
    return Scaffold(

      appBar: new AppBar(
        backgroundColor: Color(0xffD4AF4B),
        title: new Text("خدمات لبيك",textAlign: TextAlign.center,style: new TextStyle(fontSize: 20),),
      ),
      body: new Container(
        decoration: new BoxDecoration(
            image: new DecorationImage(image: AssetImage("images/back.png"),
                fit: BoxFit.fill)
        ),
        margin: EdgeInsets.only(top: 5),
height: MediaQuery.of(context).size.height,
        child: new Container(
//          decoration: new BoxDecoration(
//              image: new DecorationImage(image: AssetImage("images/back.png"),
//                  fit: BoxFit.fill)
//          ),
          margin: EdgeInsets.only(top: 80),
          child: GridView(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            children: <Widget>[
              new Card(


                  child: new Column(
                    children: <Widget>[
                      new Card(child:     new Image.asset("images/callcat1.png",height: 80,width: 100,),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(17.0),
                          side:  BorderSide(
                            color: Color(0xffBB903D),
                            width: 0.5,

                          ),),
                      ),
                      new MaterialButton(

                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17.0),
                            side:  BorderSide(
                              color: Color(0xffBB903D),
                              width: 0.5,
                            )
                        ),
                        height: 30,
                        minWidth: 200.0,

                        padding: EdgeInsets.only(top: 30,bottom: 20),
                        color: Colors.white,
                        textColor: Colors.black,
                        child: new Text("مركز اتصالات لبيك",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                        onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new callcenter()));},
                        splashColor: Colors.blueGrey,
                        autofocus: true,
                        elevation: 10,

                      ),
                    ],
                  )

              ),

              new Card(
                  child: new Column(
                    children: <Widget>[
                      new Card(child:     new Image.asset("images/smscat.png",height: 80,width: 100,),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(17.0),
                          side:  BorderSide(
                            color: Color(0xffBB903D),
                            width: 0.5,

                          ),),
                      ),
                      new MaterialButton(

                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17.0),
                            side:  BorderSide(
                              color: Color(0xffBB903D),
                              width: 0.5,
                            )
                        ),
                        height: 30,
                        minWidth: 200.0,

                        padding: EdgeInsets.only(top: 30,bottom: 20),
                        color: Colors.white,
                        textColor: Colors.black,
                        child: new Text("خدمة الرسائل النصية ",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                        onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new sms()));},
                        splashColor: Colors.blueGrey,
                        autofocus: true,
                        elevation: 10,

                      ),
                    ],
                  )

              ),



              new Card(
                  child: new Column(
                    children: <Widget>[
                      new Card(child:     new Image.asset("images/mediacat.png",height: 80,width: 100,),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(17.0),
                          side:  BorderSide(
                            color: Color(0xffBB903D),
                            width: 0.5,

                          ),),
                      ),
                      new MaterialButton(

                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17.0),
                            side:  BorderSide(
                              color: Color(0xffBB903D),
                              width: 0.5,
                            )
                        ),
                        height: 30,
                        minWidth: 200.0,

                        padding: EdgeInsets.only(top: 30,bottom: 20),
                        color: Colors.white,
                        textColor: Colors.black,
                        child: new Text("لبيك ميديا",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                        onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new media()));},
                        splashColor: Colors.blueGrey,
                        autofocus: true,
                        elevation: 10,

                      ),
                    ],
                  )
              ),
              new Card(

                  child: new Column(
                    children: <Widget>[
                      new Card(child:     new Image.asset("images/tellcat.png",height: 80,width: 100,),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(17.0),
                          side:  BorderSide(
                            color: Color(0xffBB903D),
                            width: 0.5,

                          ),),
                      ),
                      new MaterialButton(

                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(17.0),
                            side:  BorderSide(
                              color: Color(0xffBB903D),
                              width: 0.5,
                            )
                        ),
                        height: MediaQuery.of(context).size.height * 0.1,
                        minWidth: 200.0,

                        padding: EdgeInsets.only(top: 30,bottom: 20),
                        color: Colors.white,
                        textColor: Colors.black,
                        child: new Text("التسويق الالكتروني",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                        onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new tellmarkting()));},
                        splashColor: Colors.blueGrey,
                        autofocus: true,
                        elevation: 10,

                      ),
                    ],

                  )
              ),
            ],

          ),

        ),
      )
    );
  }

}

//
//new Card(
//
//child: new MaterialButton(
//
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(12.0),
//),
//height: 150.0,
//minWidth: 300.0,
//
//padding: EdgeInsets.only(top: 10,bottom: 5),
//color: Colors.red,
//textColor: Colors.white,
//child: new Text("مركز الاتصالات ",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
//onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new callcenter()));},
//splashColor: Colors.blueGrey,
//autofocus: true,
//),
//),
//
//new Card(
//child: new MaterialButton(
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(12.0),
//),
//height: 150.0,
//minWidth: 300.0,
//padding: EdgeInsets.only(top: 10,bottom: 5),
//color: Colors.green,
//textColor: Colors.white,
//child: new Text("الرسائل النصية القصيرة",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
//onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new sms()));},
//splashColor: Colors.blueGrey,
//),
//),
//
//
//
//new Card(
//child: new MaterialButton(
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(12.0),
//),
//height: 150.0,
//minWidth: 300.0,
//padding: EdgeInsets.only(top: 10,bottom: 5),
//color: Colors.orangeAccent,
//textColor: Colors.white,
//child: new Text("التسويق عبر الهاتف",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
//onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new tellmarkting()));},
//splashColor: Colors.blueGrey,
//),
//),
//new Card(
//
//child: new MaterialButton(
//
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(12.0),
//),
//height: 150.0,
//minWidth: 300.0,
//padding: EdgeInsets.only(top: 10,bottom: 5),
//color: Colors.deepPurple,
//textColor: Colors.white,
//child: new Text("لبيك ميديا",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
//onPressed:  (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new media()));},
//splashColor: Colors.blueGrey,
//),
////              margin: new EdgeInsets.all(10.0),
//),