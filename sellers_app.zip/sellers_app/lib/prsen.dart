import 'package:flutter/material.dart';
import 'package:sellers_app/pages_ar/sms.dart';
import 'main.dart';
import 'home.dart';
import 'package:sellers_app/forms/call.dart';
import 'package:sellers_app/forms/mediaaa.dart';
import 'package:sellers_app/forms/smss.dart';
import 'package:sellers_app/forms/sms2.dart';
import 'package:sellers_app/forms/tell.dart';

class prsen extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return new Scaffold(
appBar: new AppBar(
  title: new Text("نماذج الاشتراك"),

  backgroundColor: Color(0xffD4AF4B),

),

      body: new Container(
        height: MediaQuery.of(context).size.height,
        decoration: new BoxDecoration(
          image: new DecorationImage(image: new AssetImage("images/back.png"),
              fit: BoxFit.cover),
        ),
//  color: Colors.red,
//        margin: EdgeInsets.only(top: 2,bottom: 0.5),
   child: new SingleChildScrollView(
       child:Column(
   children: <Widget>[

   new Center(

     child: new Text("نماذج الاشتراك",style: TextStyle(color: Colors.black,fontSize: 26),),
        heightFactor: 4.8,
      ),


      new Center(
        child:     new MaterialButton(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17.0),
            side:  BorderSide(
              color: Color(0xffBB903D),
              width: 4.5,

            ),),
          height: 30.0,
          minWidth: 350.0,
          padding: EdgeInsets.only(top: 5,bottom: 5),
          color: Colors.white,
          textColor: Colors.black,
          child: new Text("استمارة طلب خدمة",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new call()));},
          splashColor: Colors.blueGrey,
        ),
        heightFactor: 1,

      ),
      new Center(
        child:     new MaterialButton(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17.0),
            side:  BorderSide(
              color: Color(0xffBB903D),
              width: 4.5,

            ),),
          height: 30.0,
          minWidth: 350.0,
          padding: EdgeInsets.only(top: 5,bottom: 5),
          color: Colors.white,
          textColor: Colors.black,
          child: new Text("برنامج الرسائل النصية ",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new smss()));},
          splashColor: Colors.blueGrey,
        ),
        heightFactor: 1.2,
      ),
      new Center(
        child:     new MaterialButton(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17.0),
            side:  BorderSide(
              color: Color(0xffBB903D),
              width: 4.5,

            ),),
          height: 30.0,
          minWidth: 350.0,
          padding: EdgeInsets.only(top: 5,bottom: 1),
          color: Colors.white,
          textColor: Colors.black,
          child: new Text("الرسائل  النصية القصيرة ماس",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new sms2()));},
          splashColor: Colors.blueGrey,
        ),
        heightFactor: 1.2,
      ),
      new Center(
        child:     new MaterialButton(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17.0),
            side:  BorderSide(
              color: Color(0xffBB903D),
              width: 4.5,

            ),),
          height: 30.0,
          minWidth: 350.0,
          padding: EdgeInsets.only(top: 5,bottom: 1),
          color: Colors.white,
          textColor: Colors.black,
          child: new Text("التسويق الالكتروني",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new tell()));},
          splashColor: Colors.blueGrey,
        ),
        heightFactor: 1.2,
      ),
      new Center(
        child:     new MaterialButton(

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17.0),
            side:  BorderSide(
              color: Color(0xffBB903D),
              width: 4.5,

            ),),
          height: 30.0,
          minWidth: 350.0,
          padding: EdgeInsets.only(top: 5,bottom: 1),
          color: Colors.white,
          textColor: Colors.black,
          child: new Text("لبيك ميديا",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new mediaaa()));},
          splashColor: Colors.blueGrey,
        ),
        heightFactor: 1.2,
      )
      ],
    ) ,
   ),
      ),

      );
  }

}