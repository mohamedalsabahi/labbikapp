import 'package:flutter/material.dart';
import 'package:sellers_app/main.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:share/share.dart';

class mediaaa extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffD4AF4B),

      appBar:  new AppBar(
        backgroundColor: Color(0xffD4AF4B),

        actions: <Widget>[
          new RaisedButton.icon(shape: RoundedRectangleBorder(
      borderRadius: new BorderRadius.circular(18.0)
    ),splashColor: Colors.white,onPressed: (){ Share.share("https://drive.google.com/file/d/1je6v8uK4forUUXU_O5rv7xnoHQiRK9WE/view"); }, icon: Icon(Icons.share,color: Color(0xffD4AF4B)), label: new Text("ارسال",style: TextStyle(color:Color(0xffD4AF4B)),))
        ],
        title: new Text("نموذج الميديا",style: TextStyle(color: Colors.black),),
      ),

      body: new Container(
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[

            new Container(
              margin: EdgeInsets.only(top: 5),
              width:  MediaQuery.of(context).size.width ,

              height: MediaQuery.of(context).size.height * 0.8,
              child: new Card(

                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13.0)),

                child: SizedBox(

                    height: 150.0,
                    width: 400.0,
                    child: Carousel(
                      images: [

//                  NetworkImage('https://ma.thebest-code.com/Apis/Api/images/ma/1.png'),
//                  NetworkImage('https://ma.thebest-code.com/Apis/Api/images/ma/2.png'),
//                  NetworkImage('https://ma.thebest-code.com/Apis/Api/images/ma/3.png'),
                        Image.asset("images/mediaaa.png"),
//                        Image.asset("images/fo2.png"),

//            ExactAssetImage("assets/images/LaunchImage.jpg")
                      ],
                      autoplay: false,
                      dotSize: 4.0,
                      dotSpacing: 15.0,
                      dotColor: Colors.lightGreenAccent,
                      indicatorBgPadding: 1.0,
//                dotBgColor: Colors.purple.withOpacity(0.5),
                      borderRadius: false,
                      moveIndicatorFromBottom: 200.0,
                      noRadiusForIndicator: true,
                      overlayShadow: true,
//                overlayShadowColors: Colors.purple,
                      overlayShadowSize: 0.7,
                    )
                ),

              ),
            ),

          ],
        ),
      ),

    );
  }

}