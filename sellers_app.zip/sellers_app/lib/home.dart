import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:sellers_app/profile.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:sellers_app/prsen.dart';
import 'main.dart';
import 'category.dart';
import 'package:http/http.dart' as http;
class home extends StatelessWidget{


//  _launchURL() async {
//    const url = 'https://flutter.io';
//    if (await canLaunch(url)) {
//      await launch(url);
//    } else {
//      throw 'Could not launch $url';
//    }
//  }

  @override
  Widget build(BuildContext context) {
//final data = MediaQuery.of(context);
    return new Scaffold(

      body:  new SingleChildScrollView(
        child: new  Container(
          width:  MediaQuery.of(context).size.width ,
          height: MediaQuery.of(context).size.height * 1.2,
//  margin: EdgeInsets.only(top: 40),


          child: new Container(

            child: Column(

              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                new Column(

                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[

                    SizedBox(height: 4.2,),
                    new Container(
                      height: MediaQuery.of(context).size.height * 0.3,
                      decoration: new BoxDecoration(
                          image: new DecorationImage(image: new AssetImage("images/head.png"),
                              fit: BoxFit.cover
                          )
                      ),
                    ),

                    new Container(
                      height: 400,
                      decoration: new BoxDecoration(
                        image: new DecorationImage(image: new AssetImage("images/back.png"),
                            fit: BoxFit.fill),
                      ),
//  color: Colors.red,
                      margin: EdgeInsets.only(top: 5),
                      child:Column(
                        children: <Widget>[
                      new SingleChildScrollView(
                        child:   new Column(
                          children: <Widget>[
                            new Center(
                              child:     new MaterialButton(

                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(17.0),
                                  side:  BorderSide(
                                    color: Color(0xffBB903D),
                                    width: 3,

                                  ),),
                                height: 30.0,
                                minWidth: 350.0,
                                padding: EdgeInsets.only(top: 5,bottom: 5),
                                color: Colors.white,
                                textColor: Colors.black,
                                child: new Text("اذهب الى موقع لبيك",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                                onPressed: () async {
                                  const url = 'http://labbik.om/';

                                  if (await canLaunch(url)) {
                                    await launch(url, forceSafariVC: false);
                                  } else {
                                    throw 'Could not launch $url';
                                  }
                                },
                                splashColor: Colors.blueGrey,
                              ),
                              heightFactor: 1.4,
                            ),
                            new Center(
                              child:     new MaterialButton(

                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(17.0),
                                  side:  BorderSide(
                                    color: Color(0xffBB903D),
                                    width: 3,

                                  ),),
                                height: 30.0,
                                minWidth: 350.0,
                                padding: EdgeInsets.only(top: 2,bottom: 5),
                                color: Colors.white,
                                textColor: Colors.black,
                                child: new Text("خدمات لبيك",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                                onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new category()));},
                                splashColor: Colors.blueGrey,
                              ),
                              heightFactor: 1.6,
                            ),
                            new Center(
                              child:     new MaterialButton(

                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(17.0),
                                  side:  BorderSide(
                                    color: Color(0xffBB903D),
                                    width: 3,

                                  ),),
                                height: 30.0,
                                minWidth: 350.0,
                                padding: EdgeInsets.only(top: 5,bottom: 1),
                                color: Colors.white,
                                textColor: Colors.black,
                                child: new Text("نماذج الاشتراك",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                                onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new prsen()));},
                                splashColor: Colors.blueGrey,
                              ),
                              heightFactor: 1.6,
                            ),
                            new Center(
                              child:     new MaterialButton(

                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(17.0),
                                  side:  BorderSide(
                                    color: Color(0xffBB903D),
                                    width: 3,

                                  ),),
                                height: 30.0,
                                minWidth: 350.0,
                                padding: EdgeInsets.only(top: 5,bottom: 1),
                                color: Colors.white,
                                textColor: Colors.black,
                                child: new Text("الملف الشخصي",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
                                onPressed: (){Navigator.push(context, new MaterialPageRoute(builder: (context) => new profile()));},
                                splashColor: Colors.blueGrey,
                              ),
                              heightFactor: 1.6,
                            )
                          ],
                        ),
                      )

                        ],
                      ) ,
                    ),
                    new Container(
                      color: Color(0xffD4AF4B),
                      height: 8,
                      margin: EdgeInsets.only(bottom: 1),
                    )
                  ],
                ),


              ],
            ),
          ),



        ),
      )
    );
  }



}


//new MaterialButton(
//
//shape: RoundedRectangleBorder(
//borderRadius: BorderRadius.circular(18.0),
//),
//height: 40.0,
//minWidth: 300.0,
//padding: EdgeInsets.only(top: 10,bottom: 5),
//color: Colors.deepPurple,
//textColor: Colors.white,
//child: new Text("اذهب الى موقع لبيك",textAlign: TextAlign.center,style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
//onPressed: () async {
//const url = 'http://labbik.om/';
//
//if (await canLaunch(url)) {
//await launch(url, forceSafariVC: false);
//} else {
//throw 'Could not launch $url';
//}
//},
//splashColor: Colors.blueGrey,
//),